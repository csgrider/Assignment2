package edu.bsu.cs222;

public class LeapYearCalculator {
    public boolean isLeapYear(int year) {
        return true;
    }
}
